# demo-cicd

## Contents
  - [Description](#description)
  - [Disclaimer](#disclaimer)
  - [Architecture](#architecture)
    - [CICD Base Blueprint Diagram](#cicd-base-blueprint-diagram)
    - [CICD Application Deployment Blueprint Diagram](#cicd-application-deployment-blueprint-diagram)
    - [CICD Developer Workstation Blueprint Diagram](#cicd-developer-workstation-blueprint-diagram)
    - [CICD Pipeline Diagram](#cicd-pipeline-diagram)
    - [CICD Connections and Dependencies Diagram](#cicd-connections-and-dependencies-diagram)
  - [Components](#components)
    - [Blueprints](#blueprints)
      - [CICD Base Blueprint](#cicd-base-blueprint)
      - [CICD Developer Workstation Blueprint](#cicd-developer-workstation-blueprint)
      - [CICD Application Deployment Blueprint](#cicd-application-deployment-blueprint)
    - [Application Code](#application-code)
  - [Usage](#usage)
    - [Setup](#setup)
      - [Prepare Images](#prepare-images)
      - [Prepare Demo Code](#prepare-demo-code)
      - [Prepare Blueprints](#prepare-blueprints)
    - [Launch CICD Base Blueprint](#launch-cicd-base-blueprint)
      - [Open URLs](#open-urls)
      - [Check In Code](#check-in-code)
      - [Jenkins Pipeline Run](#jenkins-pipeline-run)
      - [View CICD Application Deployment](#view-cicd-application-deployment)
      - [View Build Collateral](#view-build-collateral)
  - [To do](#to-do)
  - [Development](#development)

## Description

This project demonstrates Calm's capabilities to deploy a fully automated and configured CI/CD pipeline solving for the following use-cases:
- An IT administrator can:
    - Spin up an entire CI/CD environment using Calm so the DevOps team will have consistent deployments of the entire toolset (SCM, Build automation platform, artifact server and a sample workstation)
    - Using a day two action create a new Jenkins pipeline and Git project.
- A DevOps administrator can spin up dev workstations tied to the CI/CD environment in the previous use-case
- A developer can test/dev an application using the environments spun up in the previous use-cases

[Back to Contents](#contents)

## Disclaimer

This project is __*not*__ production-grade and is intended to simply demonstrate functionality. Please be advised that the code and blueprints may run and operate in a way that do not follow best practices and therefore need to be reviewed to ensure they meet your requirements.

[Back to Contents](#contents)

## Architecture

A Nutanix Calm blueprint builds the CI/CD pipeline deploying a private Docker registry, git repository, Artifactory instance, Jenkins Master, two Jenkins slaves and a developer workstation. Each of these components is tied together for seamless integration leveraging SSH keys and certificates. Calm configures the Jenkins Master with the necessary credentials to access the git repository, Artifactory, Docker registry and the Calm instance. Two jobs are preconfigured on the Jenkins master to handle the build and deployment of the application. The developer workstation is setup with a cloned but empty git repository. Sample application code is pre-staged on the workstation to enable quickly being able to add the code to git, commit and push it.

### CICD Base Blueprint Diagram

![CICD Base Blueprint Diagram](./images/CICDBaseBlueprint.png)

[Back to Contents](#contents)

### CICD Application Deployment Blueprint Diagram

![CICD Application Deployment Blueprint Diagram](./images/CICDApplicationDeploymentBlueprint.png)

[Back to Contents](#contents)

### CICD Developer Workstation Blueprint Diagram

![CICD Developer Workstation Blueprint Diagram](./images/CICDDeveloperWorkstationBlueprint.png)

[Back to Contents](#contents)

### CICD Pipeline Diagram

![CICD Pipeline Diagram](./images/CICDPipeline.png)

[Back to Contents](#contents)

### CICD Connections and Dependencies Diagram

![CICD Connections and Dependencies Diagram](./images/CICDDependenciesAndConnections.png)

[Back to Contents](#contents)

## Components
### Blueprints

#### CICD Base Blueprint

This is the main blueprint and deploys an entirely ephemeral, with the exception of the application code, CI/CD pipeline.

##### Services

These five services are created:
- Docker Registry
    - A local, private Docker registry
- Gitolite
    - A local, private git repository leveraging Gitolite
- Artifactory
- Jenkins Master
- Jenkins Slaves
    - Two slaves are created by default
    - These can be scaled up and down
- Developer Workstation
    - A single workstation is created by default
    - This can be scaled up and down

##### Inputs

- initial_app_deploy_blueprint
    - Name of the blueprint that launches the built application
    - Default is CICD Application Deployment
- initial_project_name
    - Name of the Git project that will be created.
- initial_code_seed
    - A web hosted location of the application code. This is pulled using wget.
- initial_code_seed_location
    - URL of the server that contains the initial code seed.
- pc_instance_ip
    - The IP address of the Prism Central instance
- domain_name
- nutanix_public_key
    - This needs to be the public key matching the private key entered into the *Nutanix Key* credential
- jenkins_public_key
    - This needs to be the public key matching the private key entered into the *Jenkins Key* credential

##### Credentials

- Ubuntu Cred
    - User name and password to log into the VMs
- Docker Registry Cred
    - User name and password to log into the private Docker registry instance
- Nutanix Key
    - Private key for the Nutanix user
- Prism Central User
    - User account with rights to launch the application blueprint
- Jenkins Key
    - Private key for the Jenkins user

##### Images

- Ubuntu-16.04-Cloud-Init
    - This is a custom Ubuntu image built from the "64-bit PC (AMD64) server install image" downloadable from the Ubuntu site. 
    - A user, "nutanix", has been created with sudo rights. Any user/password combination can be created with the matching Ubuntu Cred.
    - Cloud-Init has been pre-installed

[Back to Contents](#contents)

#### CICD Developer Workstation Blueprint

This blueprint creates a developer workstation that is connected to the CI/CD pipeline deployed via the CICD Base blueprint. This workstation has the same functionality as the workstation deployed with the CICD Base blueprint but allows a DevOps administrator to spin up dev workstations tied to the deployed CI/CD environment.

##### Services

A single service is created:
- Developer Workstation
    - This can be scaled up and down

##### Inputs

- docker_registry_name
- docker_registry_ip
- gitolite_name
- gitolite_ip
- artifactory_ip
- nutanix_public_key
    - This needs to be the public key matching the private key entered into the *Nutanix Key* credential
    - This has to match the key entered in the CICD Base blueprint
- code_seed_location
    - A web hosted location of the application code. This is pulled using wget.
- domain_name

##### Credentials

- Ubuntu Credential
    - User name and password to log into the VMs
- Nutanix
    - Private key for the Nutanix user
    - This has to match the key entered in the CICD Base blueprint

##### Images

- Ubuntu-16.04-Cloud-Init
    - This is a custom Ubuntu image built from the "64-bit PC (AMD64) server install image" downloadable from the Ubuntu site. 
    - A user, "nutanix", has been created with sudo rights. Any user/password combination can be created with the matching Ubuntu Credential.
    - Cloud-Init has been pre-installed

[Back to Contents](#contents)

#### CICD Application Deployment Blueprint

This blueprint deploys a sample application that when pushed to the git repository is built, tested and deployed onto VMs where it can be accessed by the developer or tester to validate functionality.

##### Services

- MongoDB
- NodeJS
- Nginx

##### Inputs

- artifactory_ip
- dev_project
    - This is the same project that is listed in the Makefile under application code with the build number appended.
    - Default is devops with build number appended

##### Credentials

- Ubuntu Cred
    - User name and password to log into the VMs

##### Images

- Ubuntu-16.04-Cloud-Init
    - This is a custom Ubuntu image built from the "64-bit PC (AMD64) server install image" downloadable from the Ubuntu site. 
    - A user, "nutanix", has been created with sudo rights. Any user/password combination can be created with the matching Ubuntu Credential.
    - Cloud-Init has been pre-installed

[Back to Contents](#contents)

### Application Code

The application under the devops directory is a three-tier application with the following components:
- Nginx web server
- Node.js application
- MongoDB

#### Directory Structure

```
└── devops
    ├── Jenkinsfile
    ├── Makefile
    ├── app
    │   ├── docker
    │   │   └── dev
    │   │       ├── Dockerfile
    │   │       └── docker-compose.yml
    │   ├── src
    │   │   ├── app.js
    │   │   ├── models
    │   │   │   └── peakModel.js
    │   │   ├── package.json
    │   │   └── routes
    │   │       ├── infoRoutes.js
    │   │       └── peakRoutes.js
    │   └── tests
    │       ├── package.json
    │       └── test.js
    ├── db
    │   └── mongo
    │       ├── data
    │       │   └── collections.json
    │       └── docker
    │           └── dev
    │               ├── Dockerfile
    │               └── docker-compose.yml
    ├── docker
    │   ├── dev
    │   │   ├── Dockerfile
    │   │   └── docker-compose.yml
    │   └── release
    │       └── docker-compose.yml
    ├── docker-ansible
    │   └── src
    │       ├── Dockerfile
    │       └── ansible
    │           └── probe.yml
    ├── target
    │   └── seed
    └── web
        ├── bin
        │   └── nginx-startup.sh
        ├── docker
        │   └── dev
        │       ├── Dockerfile
        │       └── docker-compose.yml
        └── src
            ├── css
            │   └── style.css
            ├── images
            │   ├── Nutanix-neg.png
            │   ├── Nutanix_X.png
            │   ├── nutanix_logo.png
            │   └── search.png
            ├── index.html
            └── js
                ├── data.js
                └── jquery-3.2.1.js

```

[Back to Contents](#contents)

## Usage

### Setup
#### Prepare Images

1. Create custom images to be used in the blueprints (see blueprint section for image details)

#### Prepare Demo Code

1. Clone this repository 
2. Change directories into the demo-cicd directory
```
cd demod-cicd
```
3. Create a gzip tar file of the code with the name of "cicd-demo-v1.tar.gz"
```
tar cvfz cicd-demo-v1.tar.gz .
```
4. Upload the gzip tar file to a web server that will be used by the CICD Base blueprint to pull the demo code onto the Developer Workstation using wget. The web server IP or FQDN will need to be entered for the "code_seed_location" input on CICD Base blueprint.

#### Prepare Blueprints

1. Upload the CICD Base and CICD Application Deployment blueprint JSON files to the Calm instance
2. Update the credentials
3. Select the appropriate custom image
4. Enter the required inputs


### Launch CICD Base Blueprint

Launch the CICD Base blueprint, provide a deployment name and click create.
The blueprint will take approximately 30 minutes to complete.

[Back to Contents](#contents)

#### Open URLs

The last steps of the blueprint deployment will output URLs for Jenkins, the private Docker registry and Artifactory.
- Jenkins Master
    - The admin password is provided above the URL
    - Copy the URL and paste into a browser
    - Enter admin in the _User:_ field
    - Copy and paste the admin password into the _Password:_ field
- Docker Registry
    - The URLs for the private docker registry are provide
    - The catalog URL provides a list of repositories
    - The tags list URL provides a list of tags available in a repository
    - Copy and paste both URLs to separate browser tabs
    - The only entries created will be those related to the Ansible image that was created and uploaded during the blueprint deployment
- Artifactory
    - The URL for the Artifactory instance is provided
    - Copy and paste into a new browser tab
    - No artifacts have been deployed at this point
- Developer Workstation
    - The IP address of the developer workstation is provided
    - SSH into the Ubuntu instance

[Back to Contents](#contents)

#### Check In Code

1. SSH into the developer workstation
2. Change directories into devops
```
cd devops/
```
3. Add all to git.
```
git add *
```
4. Commit the code.
```
git commit -m "Initial Commit."
```
5. Push the code.
```
git push -u origin master
```

[Back to Contents](#contents)

#### Jenkins Pipeline Run

Once the code is pushed to git, switch to the Jenkins browser tab to view the pipeline progress.

[Back to Contents](#contents)

#### View CICD Application Deployment

After the Jenkins pipelines have completed, switch over to the Calm instance and there will be an application deploying with the following naming convention:
```
devops<random number>Jenkins<build number>

For Example:
devops4567Jenkins1
```

Once the application deployment is complete, select the services tab, copy the IP address for the Nginx server and paste into a new browser tab to view the newly deployed running application.

[Back to Contents](#contents)

#### View Build Collateral

Artifactory
- Refresh the Artifactory page where the updated number of artifacts is displayed
- Select Artifacts icon in the left hand navigation to browse the artifacts

Docker Registry
- Refresh the catalog page to view the new repository
- Update the URL for the tags list page with the new repository name to view the tags

[Back to Contents](#contents)

## To Do

- [ ] Create Acceptance Tests
- [ ] Create Dev/Test Calm Deployment
- [ ] Create Kubernetes Deployment leveraging Karbon
- [ ] Update the Jenkins pipeline to use the Nutanix Jenkins plugin
- [ ] Implement Email notifications

[Back to Contents](#contents)

## Development

see [CONTRIBUTING.md](./CONTRIBUTING.md)

[Back to Contents](#contents)
