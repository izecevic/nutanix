# Nutanix Contributor License Agreement

By submitting a pull request or otherwise contributing to the project, you agree to the following terms and conditions.  You reserve all right and title in your contributions.  

## Grant of License 
You hereby grant Nutanix and to recipients of software distributed by Nutanix, a license to your contributions under the same license as the project.

## Representations
You represent that your contributions are your original creation, and that you are legally entitled to grant the above license.  If your contributions include other third party code, you will include complete details on any third party licenses or restrictions associated with your contributions.

## Notifications
You will notify Nutanix if you become aware that the above representations are inaccurate.  
